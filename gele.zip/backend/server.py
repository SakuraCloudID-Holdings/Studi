from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime
from emergentintegrations.llm.chat import LlmChat, UserMessage

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ==================== MODELS ====================

class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "Guest"
    email: Optional[str] = None
    preferences: Dict[str, Any] = Field(default_factory=lambda: {
        "theme": "dark",
        "language": "id",
        "default_provider": "openai",
        "default_model": "gpt-4o-mini"
    })
    custom_keys: Dict[str, str] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)

class UserCreate(BaseModel):
    name: str = "Guest"
    email: Optional[str] = None

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    preferences: Optional[Dict[str, Any]] = None
    custom_keys: Optional[Dict[str, str]] = None

class Conversation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    title: str = "New Conversation"
    mode: str = "chat"  # chat, coding, summary, explain
    provider: str = "openai"
    model: str = "gpt-4o-mini"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class ConversationCreate(BaseModel):
    user_id: str
    title: Optional[str] = "New Conversation"
    mode: str = "chat"
    provider: str = "openai"
    model: str = "gpt-4o-mini"

class Message(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    conversation_id: str
    role: str  # user or assistant
    content: str
    provider: str
    model: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class MessageCreate(BaseModel):
    conversation_id: str
    content: str

class ChatRequest(BaseModel):
    conversation_id: str
    user_id: str
    message: str
    mode: str = "chat"
    provider: str = "openai"
    model: str = "gpt-4o-mini"
    use_custom_key: bool = False

class ChatResponse(BaseModel):
    conversation_id: str
    user_message: Message
    assistant_message: Message

# ==================== HELPER FUNCTIONS ====================

def get_system_message(mode: str) -> str:
    """Get system message based on conversation mode"""
    system_messages = {
        "chat": "You are Claudie, a helpful and friendly AI assistant. Answer questions clearly and concisely.",
        "coding": "You are Claudie, an expert programming assistant. Provide clear code examples, explanations, and best practices. Format code properly with syntax highlighting.",
        "summary": "You are Claudie, an expert at summarizing content. Provide concise, well-structured summaries that capture the key points.",
        "explain": "You are Claudie, skilled at explaining complex topics in simple terms. Break down difficult concepts into easy-to-understand explanations."
    }
    return system_messages.get(mode, system_messages["chat"])

async def get_ai_response(message: str, mode: str, provider: str, model: str, api_key: str, conversation_id: str) -> str:
    """Get response from AI provider"""
    try:
        system_message = get_system_message(mode)
        
        # Initialize LlmChat
        chat = LlmChat(
            api_key=api_key,
            session_id=conversation_id,
            system_message=system_message
        )
        
        # Set model and provider
        chat.with_model(provider, model)
        
        # Create user message
        user_message = UserMessage(text=message)
        
        # Get response
        response = await chat.send_message(user_message)
        
        return response
    except Exception as e:
        logger.error(f"Error getting AI response: {str(e)}")
        raise HTTPException(status_code=500, detail=f"AI provider error: {str(e)}")

# ==================== ROUTES ====================

@api_router.get("/")
async def root():
    return {"message": "Welcome to Claudie API", "version": "1.0.0"}

# User routes
@api_router.post("/users", response_model=User)
async def create_user(input: UserCreate):
    user_dict = input.dict()
    user_obj = User(**user_dict)
    await db.users.insert_one(user_obj.dict())
    return user_obj

@api_router.get("/users/{user_id}", response_model=User)
async def get_user(user_id: str):
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return User(**user)

@api_router.put("/users/{user_id}", response_model=User)
async def update_user(user_id: str, input: UserUpdate):
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    update_data = {k: v for k, v in input.dict().items() if v is not None}
    if update_data:
        await db.users.update_one({"id": user_id}, {"$set": update_data})
    
    updated_user = await db.users.find_one({"id": user_id})
    return User(**updated_user)

# Conversation routes
@api_router.post("/conversations", response_model=Conversation)
async def create_conversation(input: ConversationCreate):
    conv_dict = input.dict()
    conv_obj = Conversation(**conv_dict)
    await db.conversations.insert_one(conv_obj.dict())
    return conv_obj

@api_router.get("/conversations/user/{user_id}", response_model=List[Conversation])
async def get_user_conversations(user_id: str):
    conversations = await db.conversations.find({"user_id": user_id}).sort("updated_at", -1).to_list(1000)
    return [Conversation(**conv) for conv in conversations]

@api_router.get("/conversations/{conversation_id}", response_model=Conversation)
async def get_conversation(conversation_id: str):
    conv = await db.conversations.find_one({"id": conversation_id})
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return Conversation(**conv)

@api_router.delete("/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str):
    # Delete conversation
    result = await db.conversations.delete_one({"id": conversation_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Delete associated messages
    await db.messages.delete_many({"conversation_id": conversation_id})
    
    return {"message": "Conversation deleted successfully"}

# Message routes
@api_router.get("/messages/conversation/{conversation_id}", response_model=List[Message])
async def get_conversation_messages(conversation_id: str):
    messages = await db.messages.find({"conversation_id": conversation_id}).sort("timestamp", 1).to_list(1000)
    return [Message(**msg) for msg in messages]

# Chat route
@api_router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        # Get user to check for custom keys
        user = await db.users.find_one({"id": request.user_id})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_obj = User(**user)
        
        # Determine API key to use
        if request.use_custom_key and request.provider in user_obj.custom_keys:
            api_key = user_obj.custom_keys[request.provider]
        else:
            api_key = os.environ.get('EMERGENT_LLM_KEY')
        
        if not api_key:
            raise HTTPException(status_code=400, detail="No API key available")
        
        # Save user message
        user_message = Message(
            conversation_id=request.conversation_id,
            role="user",
            content=request.message,
            provider=request.provider,
            model=request.model
        )
        await db.messages.insert_one(user_message.dict())
        
        # Get AI response
        ai_response = await get_ai_response(
            message=request.message,
            mode=request.mode,
            provider=request.provider,
            model=request.model,
            api_key=api_key,
            conversation_id=request.conversation_id
        )
        
        # Save assistant message
        assistant_message = Message(
            conversation_id=request.conversation_id,
            role="assistant",
            content=ai_response,
            provider=request.provider,
            model=request.model
        )
        await db.messages.insert_one(assistant_message.dict())
        
        # Update conversation's updated_at timestamp
        await db.conversations.update_one(
            {"id": request.conversation_id},
            {"$set": {"updated_at": datetime.utcnow()}}
        )
        
        return ChatResponse(
            conversation_id=request.conversation_id,
            user_message=user_message,
            assistant_message=assistant_message
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

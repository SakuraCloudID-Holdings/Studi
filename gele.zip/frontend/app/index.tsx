import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useUser } from '../contexts/UserContext';

export default function SplashScreen() {
  const router = useRouter();
  const { loading } = useUser();

  useEffect(() => {
    if (!loading) {
      // Navigate to main app after user is initialized
      setTimeout(() => {
        router.replace('/(tabs)/chat');
      }, 1000);
    }
  }, [loading]);

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Ionicons name="sparkles" size={80} color="#8b5cf6" />
        <Text style={styles.title}>Claudie</Text>
        <Text style={styles.subtitle}>Your AI Assistant</Text>
      </View>
      
      <ActivityIndicator size="large" color="#8b5cf6" style={styles.loader} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0c0c0c',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 48,
  },
  title: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 24,
  },
  subtitle: {
    fontSize: 18,
    color: '#888',
    marginTop: 8,
  },
  loader: {
    marginTop: 32,
  },
});

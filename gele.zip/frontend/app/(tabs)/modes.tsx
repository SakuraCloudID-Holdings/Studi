import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../contexts/ThemeContext';
import { useUser } from '../../contexts/UserContext';
import { useRouter } from 'expo-router';
import axios from 'axios';
import Constants from 'expo-constants';

const EXPO_PUBLIC_BACKEND_URL = Constants.expoConfig?.extra?.EXPO_PUBLIC_BACKEND_URL || process.env.EXPO_PUBLIC_BACKEND_URL;

interface Mode {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  examples: string[];
}

const modes: Mode[] = [
  {
    id: 'chat',
    name: 'General Chat',
    icon: 'chatbubble-ellipses',
    color: '#8b5cf6',
    description: 'Have natural conversations and get answers to any questions',
    examples: ['Ask me anything', 'General discussions', 'Quick questions'],
  },
  {
    id: 'coding',
    name: 'Coding Assistant',
    icon: 'code-slash',
    color: '#3b82f6',
    description: 'Get help with programming problems, debug code, and learn best practices',
    examples: [
      'Debug my code',
      'Explain this function',
      'Code optimization',
      'Algorithm help',
    ],
  },
  {
    id: 'summary',
    name: 'Text Summarizer',
    icon: 'document-text',
    color: '#10b981',
    description: 'Summarize long articles, documents, or any text into key points',
    examples: [
      'Summarize articles',
      'Key takeaways',
      'TLDR generation',
      'Meeting notes',
    ],
  },
  {
    id: 'explain',
    name: 'Concept Explainer',
    icon: 'bulb',
    color: '#f59e0b',
    description: 'Get clear explanations of complex topics in simple terms',
    examples: [
      'ELI5 explanations',
      'Complex concepts',
      'Scientific topics',
      'Technical terms',
    ],
  },
];

export default function ModesScreen() {
  const { theme } = useTheme();
  const { user, setCurrentConversationId } = useUser();
  const router = useRouter();
  const isDark = theme === 'dark';
  const [selectedMode, setSelectedMode] = useState<string | null>(null);

  const startConversation = async (mode: Mode) => {
    if (!user) return;

    try {
      const response = await axios.post(`${EXPO_PUBLIC_BACKEND_URL}/api/conversations`, {
        user_id: user.id,
        title: `${mode.name} Conversation`,
        mode: mode.id,
        provider: user.preferences.default_provider,
        model: user.preferences.default_model,
      });
      
      setCurrentConversationId(response.data.id);
      router.push('/(tabs)/chat');
    } catch (error) {
      console.error('Error creating conversation:', error);
    }
  };

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: isDark ? '#0c0c0c' : '#f5f5f5' }]}
      edges={['top']}
    >
      <View style={[styles.header, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
        <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#000' }]}>Modes</Text>
        <Text style={[styles.headerSubtitle, { color: isDark ? '#888' : '#666' }]}>
          Choose how you want to interact with Claudie
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {modes.map((mode) => (
          <TouchableOpacity
            key={mode.id}
            style={[
              styles.modeCard,
              {
                backgroundColor: isDark ? '#1a1a1a' : '#fff',
                borderColor: selectedMode === mode.id ? mode.color : 'transparent',
                borderWidth: 2,
              },
            ]}
            onPress={() => {
              setSelectedMode(mode.id);
              startConversation(mode);
            }}
            activeOpacity={0.7}
          >
            <View style={[styles.modeIconContainer, { backgroundColor: mode.color + '20' }]}>
              <Ionicons name={mode.icon as any} size={32} color={mode.color} />
            </View>

            <View style={styles.modeContent}>
              <Text style={[styles.modeName, { color: isDark ? '#fff' : '#000' }]}>
                {mode.name}
              </Text>
              <Text style={[styles.modeDescription, { color: isDark ? '#aaa' : '#666' }]}>
                {mode.description}
              </Text>

              <View style={styles.examplesContainer}>
                {mode.examples.map((example, index) => (
                  <View
                    key={index}
                    style={[
                      styles.exampleChip,
                      { backgroundColor: isDark ? '#2a2a2a' : '#f0f0f0' },
                    ]}
                  >
                    <Text style={[styles.exampleText, { color: isDark ? '#888' : '#666' }]}>
                      {example}
                    </Text>
                  </View>
                ))}
              </View>
            </View>

            <Ionicons name="chevron-forward" size={24} color={mode.color} />
          </TouchableOpacity>
        ))}

        <View style={styles.infoContainer}>
          <Ionicons name="information-circle" size={24} color="#8b5cf6" />
          <Text style={[styles.infoText, { color: isDark ? '#888' : '#666' }]}>
            You can switch between modes anytime during a conversation
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    fontSize: 14,
    marginTop: 4,
  },
  scrollContent: {
    padding: 16,
  },
  modeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  modeIconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  modeContent: {
    flex: 1,
  },
  modeName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  modeDescription: {
    fontSize: 14,
    marginBottom: 12,
    lineHeight: 20,
  },
  examplesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  exampleChip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  exampleText: {
    fontSize: 11,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
    marginTop: 8,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
  },
});

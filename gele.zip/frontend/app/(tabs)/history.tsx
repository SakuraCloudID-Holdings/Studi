import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../contexts/ThemeContext';
import { useUser } from '../../contexts/UserContext';
import { useRouter } from 'expo-router';
import axios from 'axios';
import Constants from 'expo-constants';

const EXPO_PUBLIC_BACKEND_URL = Constants.expoConfig?.extra?.EXPO_PUBLIC_BACKEND_URL || process.env.EXPO_PUBLIC_BACKEND_URL;

interface Conversation {
  id: string;
  title: string;
  mode: string;
  provider: string;
  model: string;
  created_at: string;
  updated_at: string;
}

export default function HistoryScreen() {
  const { theme } = useTheme();
  const { user, setCurrentConversationId } = useUser();
  const router = useRouter();
  const isDark = theme === 'dark';
  
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (user) {
      loadConversations();
    }
  }, [user]);

  const loadConversations = async () => {
    if (!user) return;

    try {
      const response = await axios.get(
        `${EXPO_PUBLIC_BACKEND_URL}/api/conversations/user/${user.id}`
      );
      setConversations(response.data);
    } catch (error) {
      console.error('Error loading conversations:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadConversations();
    setRefreshing(false);
  };

  const deleteConversation = async (id: string) => {
    Alert.alert(
      'Delete Conversation',
      'Are you sure you want to delete this conversation?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await axios.delete(`${EXPO_PUBLIC_BACKEND_URL}/api/conversations/${id}`);
              loadConversations();
            } catch (error) {
              console.error('Error deleting conversation:', error);
              Alert.alert('Error', 'Failed to delete conversation');
            }
          },
        },
      ]
    );
  };

  const openConversation = (conversation: Conversation) => {
    setCurrentConversationId(conversation.id);
    router.push('/(tabs)/chat');
  };

  const getModeIcon = (mode: string) => {
    const icons: Record<string, string> = {
      chat: 'chatbubble-ellipses',
      coding: 'code-slash',
      summary: 'document-text',
      explain: 'bulb',
    };
    return icons[mode] || 'chatbubble-ellipses';
  };

  const getModeColor = (mode: string) => {
    const colors: Record<string, string> = {
      chat: '#8b5cf6',
      coding: '#3b82f6',
      summary: '#10b981',
      explain: '#f59e0b',
    };
    return colors[mode] || '#8b5cf6';
  };

  const renderConversation = ({ item }: { item: Conversation }) => (
    <TouchableOpacity
      style={[
        styles.conversationCard,
        { backgroundColor: isDark ? '#1a1a1a' : '#fff' },
      ]}
      onPress={() => openConversation(item)}
    >
      <View style={styles.conversationHeader}>
        <View style={[styles.modeIcon, { backgroundColor: getModeColor(item.mode) + '20' }]}>
          <Ionicons name={getModeIcon(item.mode) as any} size={24} color={getModeColor(item.mode)} />
        </View>
        
        <View style={styles.conversationInfo}>
          <Text style={[styles.conversationTitle, { color: isDark ? '#fff' : '#000' }]}>
            {item.title}
          </Text>
          <Text style={[styles.conversationMeta, { color: isDark ? '#888' : '#666' }]}>
            {item.mode.charAt(0).toUpperCase() + item.mode.slice(1)} • {item.provider}
          </Text>
          <Text style={[styles.conversationDate, { color: isDark ? '#666' : '#999' }]}>
            {new Date(item.updated_at).toLocaleDateString()} at{' '}
            {new Date(item.updated_at).toLocaleTimeString()}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => deleteConversation(item.id)}
        >
          <Ionicons name="trash-outline" size={20} color="#ef4444" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: isDark ? '#0c0c0c' : '#f5f5f5' }]}
      edges={['top']}
    >
      <View style={[styles.header, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
        <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#000' }]}>History</Text>
        <Text style={[styles.headerSubtitle, { color: isDark ? '#888' : '#666' }]}>
          {conversations.length} conversation{conversations.length !== 1 ? 's' : ''}
        </Text>
      </View>

      {conversations.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="time-outline" size={64} color={isDark ? '#333' : '#ccc'} />
          <Text style={[styles.emptyTitle, { color: isDark ? '#888' : '#666' }]}>
            No conversations yet
          </Text>
          <Text style={[styles.emptySubtitle, { color: isDark ? '#666' : '#999' }]}>
            Start chatting with Claudie to see your history here
          </Text>
        </View>
      ) : (
        <FlatList
          data={conversations}
          renderItem={renderConversation}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#8b5cf6"
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    fontSize: 14,
    marginTop: 4,
  },
  listContainer: {
    padding: 16,
  },
  conversationCard: {
    marginBottom: 12,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  conversationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  modeIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  conversationInfo: {
    flex: 1,
  },
  conversationTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  conversationMeta: {
    fontSize: 14,
    marginBottom: 4,
  },
  conversationDate: {
    fontSize: 12,
  },
  deleteButton: {
    padding: 8,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
});

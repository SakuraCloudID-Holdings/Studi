import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../contexts/ThemeContext';
import { useUser } from '../../contexts/UserContext';
import axios from 'axios';
import Constants from 'expo-constants';
import SyntaxHighlighter from 'react-native-syntax-highlighter';
import { atomOneDark, atomOneLight } from 'react-syntax-highlighter/styles/hljs';

const EXPO_PUBLIC_BACKEND_URL = Constants.expoConfig?.extra?.EXPO_PUBLIC_BACKEND_URL || process.env.EXPO_PUBLIC_BACKEND_URL;

interface Message {
  id: string;
  role: string;
  content: string;
  timestamp: string;
}

export default function ChatScreen() {
  const { theme } = useTheme();
  const { user, currentConversationId, setCurrentConversationId } = useUser();
  const isDark = theme === 'dark';
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState('chat');
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    initializeConversation();
  }, [user]);

  useEffect(() => {
    if (currentConversationId) {
      loadMessages();
    }
  }, [currentConversationId]);

  const initializeConversation = async () => {
    if (!user) return;

    if (!currentConversationId) {
      try {
        const response = await axios.post(`${EXPO_PUBLIC_BACKEND_URL}/api/conversations`, {
          user_id: user.id,
          title: 'New Conversation',
          mode: mode,
          provider: user.preferences.default_provider,
          model: user.preferences.default_model,
        });
        setCurrentConversationId(response.data.id);
      } catch (error) {
        console.error('Error creating conversation:', error);
      }
    }
  };

  const loadMessages = async () => {
    if (!currentConversationId) return;

    try {
      const response = await axios.get(
        `${EXPO_PUBLIC_BACKEND_URL}/api/messages/conversation/${currentConversationId}`
      );
      setMessages(response.data);
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || !user || !currentConversationId) return;

    const userMessage = input.trim();
    setInput('');
    setLoading(true);

    try {
      const response = await axios.post(`${EXPO_PUBLIC_BACKEND_URL}/api/chat`, {
        conversation_id: currentConversationId,
        user_id: user.id,
        message: userMessage,
        mode: mode,
        provider: user.preferences.default_provider,
        model: user.preferences.default_model,
        use_custom_key: false,
      });

      setMessages([...messages, response.data.user_message, response.data.assistant_message]);
      
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Failed to send message. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const detectCodeBlock = (text: string) => {
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    return codeBlockRegex.test(text);
  };

  const renderCodeBlock = (text: string) => {
    const parts = [];
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      // Add text before code block
      if (match.index > lastIndex) {
        parts.push({
          type: 'text',
          content: text.substring(lastIndex, match.index),
        });
      }

      // Add code block
      parts.push({
        type: 'code',
        language: match[1] || 'javascript',
        content: match[2],
      });

      lastIndex = match.index + match[0].length;
    }

    // Add remaining text
    if (lastIndex < text.length) {
      parts.push({
        type: 'text',
        content: text.substring(lastIndex),
      });
    }

    return parts;
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isUser = item.role === 'user';
    const hasCode = detectCodeBlock(item.content);

    return (
      <View
        style={[
          styles.messageContainer,
          isUser ? styles.userMessage : styles.assistantMessage,
        ]}
      >
        <View style={styles.messageHeader}>
          <Ionicons
            name={isUser ? 'person-circle' : 'sparkles'}
            size={20}
            color={isUser ? '#8b5cf6' : '#ec4899'}
          />
          <Text style={[styles.messageSender, { color: isDark ? '#fff' : '#000' }]}>
            {isUser ? 'You' : 'Claudie'}
          </Text>
        </View>
        
        {hasCode ? (
          <View>
            {renderCodeBlock(item.content).map((part, index) => (
              <View key={index}>
                {part.type === 'text' ? (
                  <Text style={[styles.messageText, { color: isDark ? '#ddd' : '#333' }]}>
                    {part.content}
                  </Text>
                ) : (
                  <View style={styles.codeContainer}>
                    <View style={styles.codeHeader}>
                      <Text style={styles.codeLanguage}>{part.language}</Text>
                    </View>
                    <SyntaxHighlighter
                      language={part.language}
                      style={isDark ? atomOneDark : atomOneLight}
                      customStyle={{
                        padding: 12,
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                    >
                      {part.content}
                    </SyntaxHighlighter>
                  </View>
                )}
              </View>
            ))}
          </View>
        ) : (
          <Text style={[styles.messageText, { color: isDark ? '#ddd' : '#333' }]}>
            {item.content}
          </Text>
        )}
        
        <Text style={[styles.timestamp, { color: isDark ? '#666' : '#999' }]}>
          {new Date(item.timestamp).toLocaleTimeString()}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: isDark ? '#0c0c0c' : '#f5f5f5' }]}
      edges={['top']}
    >
      <View style={[styles.header, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
        <View style={styles.headerTop}>
          <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#000' }]}>Claudie</Text>
          <TouchableOpacity
            style={styles.newChatButton}
            onPress={() => {
              setCurrentConversationId(null);
              setMessages([]);
              initializeConversation();
            }}
          >
            <Ionicons name="add-circle" size={28} color="#8b5cf6" />
          </TouchableOpacity>
        </View>
        
        <View style={styles.modeSelector}>
          {['chat', 'coding', 'summary', 'explain'].map((m) => (
            <TouchableOpacity
              key={m}
              style={[
                styles.modeChip,
                mode === m && styles.modeChipActive,
                { backgroundColor: mode === m ? '#8b5cf6' : (isDark ? '#2a2a2a' : '#e0e0e0') },
              ]}
              onPress={() => setMode(m)}
            >
              <Text
                style={[
                  styles.modeChipText,
                  { color: mode === m ? '#fff' : (isDark ? '#aaa' : '#666') },
                ]}
              >
                {m.charAt(0).toUpperCase() + m.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        {messages.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="sparkles" size={64} color="#8b5cf6" />
            <Text style={[styles.emptyTitle, { color: isDark ? '#fff' : '#000' }]}>
              Welcome to Claudie!
            </Text>
            <Text style={[styles.emptySubtitle, { color: isDark ? '#888' : '#666' }]}>
              Your AI assistant for coding, summaries, and explanations
            </Text>
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            renderItem={renderMessage}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.messagesList}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd()}
          />
        )}

        <View style={[styles.inputContainer, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: isDark ? '#2a2a2a' : '#f0f0f0',
                color: isDark ? '#fff' : '#000',
              },
            ]}
            value={input}
            onChangeText={setInput}
            placeholder="Type your message..."
            placeholderTextColor={isDark ? '#666' : '#999'}
            multiline
            maxLength={2000}
            editable={!loading}
          />
          <TouchableOpacity
            style={[styles.sendButton, { opacity: loading || !input.trim() ? 0.5 : 1 }]}
            onPress={sendMessage}
            disabled={loading || !input.trim()}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Ionicons name="send" size={24} color="#fff" />
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  newChatButton: {
    padding: 4,
  },
  modeSelector: {
    flexDirection: 'row',
    gap: 8,
  },
  modeChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  modeChipActive: {
    shadowColor: '#8b5cf6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  modeChipText: {
    fontSize: 14,
    fontWeight: '600',
  },
  keyboardView: {
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 8,
  },
  messagesList: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  messageContainer: {
    marginBottom: 16,
    padding: 12,
    borderRadius: 12,
  },
  userMessage: {
    backgroundColor: '#8b5cf620',
    alignSelf: 'flex-end',
    maxWidth: '85%',
  },
  assistantMessage: {
    backgroundColor: '#ec489920',
    alignSelf: 'flex-start',
    maxWidth: '90%',
  },
  messageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 6,
  },
  messageSender: {
    fontSize: 14,
    fontWeight: '600',
  },
  messageText: {
    fontSize: 16,
    lineHeight: 24,
  },
  codeContainer: {
    marginVertical: 8,
    borderRadius: 8,
    overflow: 'hidden',
  },
  codeHeader: {
    backgroundColor: '#2a2a2a',
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  codeLanguage: {
    color: '#aaa',
    fontSize: 12,
    fontWeight: '600',
  },
  timestamp: {
    fontSize: 12,
    marginTop: 6,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: '#333',
  },
  input: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 24,
    fontSize: 16,
    maxHeight: 120,
  },
  sendButton: {
    backgroundColor: '#8b5cf6',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

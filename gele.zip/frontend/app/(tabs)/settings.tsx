import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../contexts/ThemeContext';
import { useUser } from '../../contexts/UserContext';

interface SettingSection {
  title: string;
  items: SettingItem[];
}

interface SettingItem {
  id: string;
  label: string;
  icon: string;
  type: 'toggle' | 'select' | 'input' | 'action';
  value?: any;
  options?: { label: string; value: string }[];
}

export default function SettingsScreen() {
  const { theme, toggleTheme } = useTheme();
  const { user, updateUser } = useUser();
  const isDark = theme === 'dark';
  
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState('');

  const handleThemeToggle = () => {
    toggleTheme();
  };

  const handleLanguageChange = async (language: string) => {
    if (!user) return;
    try {
      await updateUser({
        preferences: {
          ...user.preferences,
          language,
        },
      });
      Alert.alert('Success', 'Language updated successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to update language');
    }
  };

  const handleProviderChange = async (provider: string) => {
    if (!user) return;
    try {
      await updateUser({
        preferences: {
          ...user.preferences,
          default_provider: provider,
        },
      });
      Alert.alert('Success', 'AI provider updated successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to update provider');
    }
  };

  const handleModelChange = async (model: string) => {
    if (!user) return;
    try {
      await updateUser({
        preferences: {
          ...user.preferences,
          default_model: model,
        },
      });
      Alert.alert('Success', 'Model updated successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to update model');
    }
  };

  const saveApiKey = async () => {
    if (!user || !selectedProvider || !apiKeyInput.trim()) {
      Alert.alert('Error', 'Please enter a valid API key');
      return;
    }

    try {
      const newKeys = { ...user.custom_keys, [selectedProvider]: apiKeyInput.trim() };
      await updateUser({ custom_keys: newKeys });
      Alert.alert('Success', 'API key saved successfully');
      setApiKeyInput('');
      setSelectedProvider(null);
      setShowApiKeyInput(false);
    } catch (error) {
      Alert.alert('Error', 'Failed to save API key');
    }
  };

  const removeApiKey = async (provider: string) => {
    if (!user) return;

    Alert.alert(
      'Remove API Key',
      `Are you sure you want to remove your ${provider} API key?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              const newKeys = { ...user.custom_keys };
              delete newKeys[provider];
              await updateUser({ custom_keys: newKeys });
              Alert.alert('Success', 'API key removed successfully');
            } catch (error) {
              Alert.alert('Error', 'Failed to remove API key');
            }
          },
        },
      ]
    );
  };

  const getProviderModels = (provider: string) => {
    const models: Record<string, { label: string; value: string }[]> = {
      openai: [
        { label: 'GPT-4o Mini (Recommended)', value: 'gpt-4o-mini' },
        { label: 'GPT-4o', value: 'gpt-4o' },
        { label: 'GPT-4', value: 'gpt-4' },
      ],
      anthropic: [
        { label: 'Claude 3.7 Sonnet', value: 'claude-3-7-sonnet-20250219' },
        { label: 'Claude 3.5 Sonnet', value: 'claude-3-5-sonnet-20241022' },
      ],
      gemini: [
        { label: 'Gemini 2.5 Flash', value: 'gemini-2.5-flash' },
        { label: 'Gemini 2.0 Flash', value: 'gemini-2.0-flash' },
        { label: 'Gemini 2.5 Pro', value: 'gemini-2.5-pro' },
      ],
    };
    return models[provider] || [];
  };

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: isDark ? '#0c0c0c' : '#f5f5f5' }]}
      edges={['top']}
    >
      <View style={[styles.header, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
        <Text style={[styles.headerTitle, { color: isDark ? '#fff' : '#000' }]}>Settings</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Appearance Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#aaa' : '#666' }]}>Appearance</Text>
          
          <View style={[styles.settingCard, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Ionicons
                  name={isDark ? 'moon' : 'sunny'}
                  size={24}
                  color={isDark ? '#8b5cf6' : '#f59e0b'}
                />
                <Text style={[styles.settingLabel, { color: isDark ? '#fff' : '#000' }]}>
                  Dark Mode
                </Text>
              </View>
              <Switch
                value={isDark}
                onValueChange={handleThemeToggle}
                trackColor={{ false: '#ccc', true: '#8b5cf6' }}
                thumbColor="#fff"
              />
            </View>
          </View>
        </View>

        {/* Language Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#aaa' : '#666' }]}>Language</Text>
          
          <View style={[styles.settingCard, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
            <TouchableOpacity
              style={styles.settingRow}
              onPress={() =>
                Alert.alert('Select Language', '', [
                  {
                    text: 'English',
                    onPress: () => handleLanguageChange('en'),
                  },
                  {
                    text: 'Bahasa Indonesia',
                    onPress: () => handleLanguageChange('id'),
                  },
                  { text: 'Cancel', style: 'cancel' },
                ])
              }
            >
              <View style={styles.settingLeft}>
                <Ionicons name="language" size={24} color="#8b5cf6" />
                <Text style={[styles.settingLabel, { color: isDark ? '#fff' : '#000' }]}>
                  Interface Language
                </Text>
              </View>
              <View style={styles.settingRight}>
                <Text style={[styles.settingValue, { color: isDark ? '#888' : '#666' }]}>
                  {user?.preferences.language === 'id' ? 'Bahasa Indonesia' : 'English'}
                </Text>
                <Ionicons name="chevron-forward" size={20} color="#888" />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* AI Provider Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#aaa' : '#666' }]}>AI Provider</Text>
          
          <View style={[styles.settingCard, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
            <TouchableOpacity
              style={styles.settingRow}
              onPress={() =>
                Alert.alert('Select AI Provider', '', [
                  {
                    text: 'OpenAI',
                    onPress: () => handleProviderChange('openai'),
                  },
                  {
                    text: 'Anthropic Claude',
                    onPress: () => handleProviderChange('anthropic'),
                  },
                  {
                    text: 'Google Gemini',
                    onPress: () => handleProviderChange('gemini'),
                  },
                  { text: 'Cancel', style: 'cancel' },
                ])
              }
            >
              <View style={styles.settingLeft}>
                <Ionicons name="hardware-chip" size={24} color="#3b82f6" />
                <Text style={[styles.settingLabel, { color: isDark ? '#fff' : '#000' }]}>
                  Default Provider
                </Text>
              </View>
              <View style={styles.settingRight}>
                <Text style={[styles.settingValue, { color: isDark ? '#888' : '#666' }]}>
                  {user?.preferences.default_provider || 'openai'}
                </Text>
                <Ionicons name="chevron-forward" size={20} color="#888" />
              </View>
            </TouchableOpacity>

            <View style={[styles.divider, { backgroundColor: isDark ? '#2a2a2a' : '#f0f0f0' }]} />

            <TouchableOpacity
              style={styles.settingRow}
              onPress={() => {
                const models = getProviderModels(user?.preferences.default_provider || 'openai');
                Alert.alert(
                  'Select Model',
                  '',
                  [
                    ...models.map((model) => ({
                      text: model.label,
                      onPress: () => handleModelChange(model.value),
                    })),
                    { text: 'Cancel', style: 'cancel' },
                  ]
                );
              }}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="options" size={24} color="#10b981" />
                <Text style={[styles.settingLabel, { color: isDark ? '#fff' : '#000' }]}>
                  Default Model
                </Text>
              </View>
              <View style={styles.settingRight}>
                <Text style={[styles.settingValue, { color: isDark ? '#888' : '#666' }]}>
                  {user?.preferences.default_model || 'gpt-4o-mini'}
                </Text>
                <Ionicons name="chevron-forward" size={20} color="#888" />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* API Keys Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#aaa' : '#666' }]}>Custom API Keys (Optional)</Text>
          <Text style={[styles.sectionSubtitle, { color: isDark ? '#666' : '#999' }]}>
            By default, Claudie uses Emergent LLM Key. Add your own keys if you prefer.
          </Text>
          
          <View style={[styles.settingCard, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
            {['openai', 'anthropic', 'gemini'].map((provider, index) => (
              <View key={provider}>
                {index > 0 && (
                  <View style={[styles.divider, { backgroundColor: isDark ? '#2a2a2a' : '#f0f0f0' }]} />
                )}
                <View style={styles.settingRow}>
                  <View style={styles.settingLeft}>
                    <Ionicons name="key" size={24} color="#8b5cf6" />
                    <Text style={[styles.settingLabel, { color: isDark ? '#fff' : '#000' }]}>
                      {provider.charAt(0).toUpperCase() + provider.slice(1)}
                    </Text>
                  </View>
                  {user?.custom_keys?.[provider] ? (
                    <TouchableOpacity
                      style={styles.removeButton}
                      onPress={() => removeApiKey(provider)}
                    >
                      <Ionicons name="trash-outline" size={20} color="#ef4444" />
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      style={styles.addButton}
                      onPress={() => {
                        setSelectedProvider(provider);
                        setShowApiKeyInput(true);
                      }}
                    >
                      <Text style={styles.addButtonText}>Add</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* API Key Input Modal */}
        {showApiKeyInput && selectedProvider && (
          <View style={[styles.modalCard, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: isDark ? '#fff' : '#000' }]}>
                Add {selectedProvider} API Key
              </Text>
              <TouchableOpacity onPress={() => {
                setShowApiKeyInput(false);
                setSelectedProvider(null);
                setApiKeyInput('');
              }}>
                <Ionicons name="close" size={24} color="#888" />
              </TouchableOpacity>
            </View>
            <TextInput
              style={[
                styles.apiKeyInput,
                {
                  backgroundColor: isDark ? '#2a2a2a' : '#f0f0f0',
                  color: isDark ? '#fff' : '#000',
                },
              ]}
              value={apiKeyInput}
              onChangeText={setApiKeyInput}
              placeholder="Enter your API key"
              placeholderTextColor="#888"
              secureTextEntry
            />
            <TouchableOpacity style={styles.saveButton} onPress={saveApiKey}>
              <Text style={styles.saveButtonText}>Save API Key</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* About Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: isDark ? '#aaa' : '#666' }]}>About</Text>
          
          <View style={[styles.settingCard, { backgroundColor: isDark ? '#1a1a1a' : '#fff' }]}>
            <View style={styles.aboutRow}>
              <Text style={[styles.aboutLabel, { color: isDark ? '#fff' : '#000' }]}>Version</Text>
              <Text style={[styles.aboutValue, { color: isDark ? '#888' : '#666' }]}>1.0.0</Text>
            </View>
            <View style={[styles.divider, { backgroundColor: isDark ? '#2a2a2a' : '#f0f0f0' }]} />
            <View style={styles.aboutRow}>
              <Text style={[styles.aboutLabel, { color: isDark ? '#fff' : '#000' }]}>User ID</Text>
              <Text style={[styles.aboutValue, { color: isDark ? '#888' : '#666' }]} numberOfLines={1}>
                {user?.id.substring(0, 8)}...
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  scrollContent: {
    paddingBottom: 32,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  sectionSubtitle: {
    fontSize: 12,
    marginBottom: 8,
    lineHeight: 16,
  },
  settingCard: {
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
  },
  settingRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  settingValue: {
    fontSize: 14,
  },
  divider: {
    height: 1,
    marginHorizontal: 16,
  },
  addButton: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    backgroundColor: '#8b5cf6',
    borderRadius: 16,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  removeButton: {
    padding: 8,
  },
  modalCard: {
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  apiKeyInput: {
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    marginBottom: 16,
  },
  saveButton: {
    backgroundColor: '#8b5cf6',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  aboutRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  aboutLabel: {
    fontSize: 16,
  },
  aboutValue: {
    fontSize: 14,
    maxWidth: 200,
  },
});

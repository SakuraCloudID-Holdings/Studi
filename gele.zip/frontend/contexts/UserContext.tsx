import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import Constants from 'expo-constants';

const EXPO_PUBLIC_BACKEND_URL = Constants.expoConfig?.extra?.EXPO_PUBLIC_BACKEND_URL || process.env.EXPO_PUBLIC_BACKEND_URL;

interface User {
  id: string;
  name: string;
  email?: string;
  preferences: {
    theme: string;
    language: string;
    default_provider: string;
    default_model: string;
  };
  custom_keys: Record<string, string>;
}

interface UserContextType {
  user: User | null;
  loading: boolean;
  initializeUser: () => Promise<void>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  currentConversationId: string | null;
  setCurrentConversationId: (id: string | null) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);

  useEffect(() => {
    initializeUser();
  }, []);

  const initializeUser = async () => {
    try {
      // Check if user exists in AsyncStorage
      const savedUserId = await AsyncStorage.getItem('userId');
      
      if (savedUserId) {
        // Fetch user from backend
        const response = await axios.get(`${EXPO_PUBLIC_BACKEND_URL}/api/users/${savedUserId}`);
        setUser(response.data);
      } else {
        // Create new user
        const response = await axios.post(`${EXPO_PUBLIC_BACKEND_URL}/api/users`, {
          name: 'Guest'
        });
        setUser(response.data);
        await AsyncStorage.setItem('userId', response.data.id);
      }
    } catch (error) {
      console.error('Error initializing user:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateUser = async (updates: Partial<User>) => {
    if (!user) return;
    
    try {
      const response = await axios.put(
        `${EXPO_PUBLIC_BACKEND_URL}/api/users/${user.id}`,
        updates
      );
      setUser(response.data);
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  };

  return (
    <UserContext.Provider value={{ 
      user, 
      loading, 
      initializeUser, 
      updateUser,
      currentConversationId,
      setCurrentConversationId
    }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
